

<?php
	//Servidor, Usuario, Contraseña, nombre de la base de datos
	$mysqli = new mysqli('localhost','root','','bdcertificados');


	/*if ($mysqli->connect_error){
		die('Error en la conexion'. $mysqli->connect_error);
	}
	*/
	
?>